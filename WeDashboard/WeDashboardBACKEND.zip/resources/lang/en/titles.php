<?php

return [

    'app'               => 'Laravel',
    'app2'              => 'Auth :version',
    'home'              => 'Home',
    'login'             => 'Login',
    'logout'            => 'Logout',
    'register'          => 'Register',
    'resetPword'        => 'Reset Password',
    'toggleNav'         => 'Toggle Navigation',
    'profile'           => 'Profile',
    'editProfile'       => 'Edit Profile',
    'myUserLogs'        => 'My Logs',
    'editBusiness'      => 'Manage Business',
    'myBusinessLogs'    => 'Business Logs',
    'createProfile'     => 'Create Profile',
    'adminDropdownNav'  => 'Admin',
    'userInformation'   => 'User Information',

    'activation'        => 'Registration Started  | Activation Required',
    'exceeded'          => 'Activation Error',

    'editProfile'       => 'Edit Profile',
    'createProfile'     => 'Create Profile',
    'adminUserList'     => 'Users Administration',
    'adminEditUsers'    => 'Edit Users',
    'adminNewUser'      => 'Create New User',

    'adminThemesList'   => 'Themes',
    'adminThemesAdd'    => 'Add New Theme',

    'adminLogs'         => 'Log Files',
    'adminActivity'     => 'Activity Log',
    'adminPHP'          => 'PHP Information',
    'adminRoutes'       => 'Routing Details',

    'activeUsers'       => 'Active Users',
];
