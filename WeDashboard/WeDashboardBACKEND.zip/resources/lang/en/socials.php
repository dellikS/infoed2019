<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Socialite and Social Media Language Lines
    |--------------------------------------------------------------------------
    |
    */

    'denied'          => 'You did not share your profile data with our social app. ',
    'noProvider'      => 'No such provider. ',
    'registerSuccess' => 'You have successfully registered! ',

];
