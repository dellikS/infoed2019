<?php

return [

    // Permissions
    'permissionView'   => 'Vizualizeaza',
    'permissionCreate' => 'Creeaza',
    'permissionEdit'   => 'Editeaza',
    'permissionDelete' => 'Sterge',

];
