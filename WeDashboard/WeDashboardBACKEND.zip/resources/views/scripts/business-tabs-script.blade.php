<script type="text/javascript">

    $(document).ready(function() {
        /*---------------------------------------------------------*/
        $(".btn-next").click(function() { // Function Runs On NEXT Button Click
            $(this).parent().next().fadeIn('slow');
            $(this).parent().css({
                'display': 'none'
            });
        // Adding Class Active To Show Steps Forward;
        $('.active').next().addClass('active');
        });
        $(".btn-prev").click(function() { // Function Runs On PREVIOUS Button Click
            $(this).parent().prev().fadeIn('slow');
            $(this).parent().css({
                'display': 'none'
            });
            // Removing Class Active To Show Steps Backward;
            $('.active:last').removeClass('active');
        });
    });
</script>

<script type="text/javascript">
function isEmpty( el ){
    return !$.trim(el.html())
}
</script>

<script type="text/javascript">
    var country_id = $("#country_id").val();
    $(".prefix").text("+ " + country_id);
function changePrefix() {
    var country_id = $("#country_id").val();
    $(".prefix").text("+ " + country_id);
}
</script>

<script type="text/javascript">
    var currency = "NULL";
    if (isEmpty($(".currency"))){
        $(".currency").text(currency);
    }
function changeCurrency() {
    var currency = $("#currency").val();
    $(".currency").text(currency);
}
</script>